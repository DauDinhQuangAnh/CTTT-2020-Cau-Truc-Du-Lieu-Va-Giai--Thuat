#include<iostream>
using namespace std;

struct node 
{
    int data;
    struct node *pnext; 
};
typedef struct node NODE; 


struct queue{ 
    NODE *pHead; 
    NODE *pTail;
};
typedef struct queue QUEUE;

void CreateQueue(QUEUE &s)
{
    s.pHead= NULL;
    s.pTail= NULL;
}


NODE *createNODE(int x){
    NODE *p= new NODE;
    if(p==NULL){
        return NULL;
    }
    p -> data = x;
    p -> pnext = NULL;
    return p;
}

void addFRONT(QUEUE &s, int x){
    NODE *p = createNODE(x);
    if(s.pHead== NULL){
        s.pHead = s.pTail =p;
    }
    else{
        s.pTail->pnext=p;
        s.pTail=p;
    }
}

void nhap(QUEUE &s, int n){

    for (int i =1;i<=n;i++){
        int x;
        cout << " Nhap vao cac gia tri: ";
        cin>> x;
        addFRONT(s, x);
    }
}

void deleteREAR(QUEUE &s, int &value){
    if(s.pHead == NULL){
        s.pHead=s.pTail=NULL;
    }
    else{
        NODE *p = s.pHead;
        value = p->data;
        s.pHead = s.pHead->pnext;
        delete p;
        
    }
}

void REARandFRONT(QUEUE &s){
    cout << "Queue <" << s.pHead->data<<"...."<<s.pTail->data<<"  >"<<endl;
    
}



void printQueue(QUEUE s){
    cout << "Queue = REAR<  ";
    for (NODE *k =s.pHead; k!= NULL ; k=k->pnext){
        cout << k->data << "  ";
    }
    cout << ">FRONT" << endl;
}


bool checkrong(QUEUE s){
    if(s.pHead == NULL){
        return true;   
    }
    else{
        return false;
    }
}

void checkfull(QUEUE s){
    
}

int main(){
QUEUE s;
CreateQueue(s);

while (true){
    cout << "1. Viet ham khoi tao queue" << endl;
    cout << "2. Check queue rong. Rong la true, ko rong la false" << endl;
    cout << "3. Check queue co full hay khong. Full la true, ko full la false " << endl;
    cout << "4. Dua 1 phan tu vao queue" << endl;
    cout << "5. Lay 1 phan tu ra queue" << endl;
    cout << "6. Xuat ra phan tu REAR and FRONT of queue" <<endl;


int chon;
cout << "Lua chon cua ban la: "<< endl;
cin >> chon ;
    switch (chon)
    {
    case 1:{
        cout << "Em da viet, thua Thay :33" << endl;  
        break;
    }

    case 2:{
        checkrong(s);
        break;   
    }

    case 3:{
        
        break;    
    }

    case 4:{
        int n;
        cout << "Nhap so luong Node can them: " << endl;
        cin >> n;
        nhap(s,n);
        break; 
    }

    case 5:{
        int value;
        deleteREAR(s,value);
        break; 
    }
    
    case 6:{
        REARandFRONT(s);
        break;
    }
    case 7:{
        printQueue(s);
        break;
    }
    default:
        break;
    }
}
}