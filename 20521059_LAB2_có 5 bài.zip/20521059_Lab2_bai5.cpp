#include<iostream>
using namespace std;

struct node 
{
    int data;
    struct node *pnext; 
};
typedef struct node NODE; 


struct stack{ 
    NODE *Top; 
};
typedef struct list LIST;


NODE *createNODE(int x){
    NODE *p= new NODE;
    if(p==NULL){
        return NULL;
    }
    p -> data = x;
    p -> pnext = NULL;
    return p;
}
void createstack(stack &s)
{
    s.Top= NULL;
}


void push(stack &s, int x){
    NODE *p = createNODE(x);
    if(s.Top == NULL){
        s.Top=p;
    }
    else{
        p->pnext =s.Top;
        s.Top = p;
    }
}

void pop (stack &s, int value){
    if(s.Top == NULL){
        return; 
    }
    else {
        NODE *p =s.Top;
        s.Top =p ->pnext;
        value = p->data;
        delete p ;
    }
}

void nhap(stack &s, int n){

    for (int i =1;i<=n;i++){
        int x;
        cout << " Nhap vao cac gia tri: ";
        cin>> x;
        push(s, x);
    }
}

void printstack(stack s){
    cout << "<  ";
    for (NODE *k =s.Top; k!= NULL ; k=k->pnext){
        cout << k->data << " ";
    }
    cout << ">" << endl;
}


void printtop(stack &s){
    cout << s.Top->data << endl; 
} 


bool checkrong(stack &s){
    if(s.Top = NULL){
        return 1;}

    return 0;
}

void Chuyen_Co_So(stack &s, int hethapphan)
{
    while (hethapphan != 0)
    {
        int x = hethapphan % 2;
     
        push(s, x);
        hethapphan /= 2;
    }
}

int main(){
stack s;
createstack(s);
int n;
cout << "Nhap Gia Tri: ";
cin >> n;
Chuyen_Co_So(s,n);
printstack(s);
    return 0;
}
