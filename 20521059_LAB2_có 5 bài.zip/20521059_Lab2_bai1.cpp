#include<iostream>
using namespace std;

struct node 
{
    int data;
    struct node *pnext; 
};
typedef struct node NODE; 


struct stack{ 
    NODE *Top; 
};
typedef struct list LIST;


NODE *createNODE(int x){
    NODE *p= new NODE;
    if(p==NULL){
        return NULL;
    }
    p -> data = x;
    p -> pnext = NULL;
    return p;
}
void createstack(stack &s)
{
    s.Top= NULL;
}


void push(stack &s, int x){
    NODE *p = createNODE(x);
    if(s.Top == NULL){
        s.Top=p;
    }
    else{
        p->pnext =s.Top;
        s.Top = p;
    }
}

void pop (stack &s, int value){
    if(s.Top == NULL){
        return; 
    }
    else {
        NODE *p =s.Top;
        s.Top =p ->pnext;
        value = p->data;
        delete p ;
    }
}

void nhap(stack &s, int n){

    for (int i =1;i<=n;i++){
        int x;
        cout << " Nhap vao cac gia tri: ";
        cin>> x;
        push(s, x);
    }
}

void printstack(stack s){
    cout << "STACK = Top<  ";
    for (NODE *k =s.Top; k!= NULL ; k=k->pnext){
        cout << k->data << "  ";
    }
    cout << ">" << endl;
}


void printtop(stack &s){
    cout << s.Top->data << endl; 
} 


bool checkrong(stack &s){
    if(s.Top = NULL){
        return 1;}

    return 0;
}

bool checkfull(stack &s){
    int full=10000;
    int dem=1;
    for (NODE *p =s.Top; p!= NULL ; p=p->pnext){
        dem ++;
    }
    if(dem==full){
        cout << "Stack da full"<< endl;
    }
    else {cout << " Stack chua full";
    }

}


int main(){
stack s;
createstack(s);

while (true){
    cout << "1. Kiem Tra Rong" << endl;
    cout << "2. Kiem Tra Full" << endl;
    cout << "3. Day 1 Phan Tu Vao Stack" << endl;
    cout << "4. Lay 1 Phan Tu Ra Khoi Stack" << endl;
    cout << "5. Xuat Ra Phan Tu Top Cua Stack" << endl;
    cout << "6. Xuat full stack" <<endl;


int chon;
cout << "Lua chon cua ban la: "<< endl;
cin >> chon ;
    switch (chon)
    {
    case 1:{
        cout << checkrong(s);
        break;   
    }

    case 2:{
        checkfull(s);
        break;   
    }

    case 3:{
        int n;
        cout << "Nhap so luong Node can them: " << endl;
        cin >> n;
        nhap(s,n);
        break;   
    }

    case 4:{
        int value;
        pop(s,value);
        cout << "Da xoa" << value << endl;
        break;   
    }

    case 5:{
        printtop(s);
        break;   
    }
    
    case 6:{
        printstack(s);
        break;
    }
    default:
        break;
    }
}
}