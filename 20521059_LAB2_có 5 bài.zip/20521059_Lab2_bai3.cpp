#include<iostream>
using namespace std;

struct node 
{
    int data;
    struct node *pnext; 
};
typedef struct node NODE; 


struct stack{ 
    NODE *Top; 
};
typedef struct list LIST;


NODE *createNODE(int x){
    NODE *p= new NODE;
    if(p==NULL){
        return NULL;
    }
    p -> data = x;
    p -> pnext = NULL;
    return p;
}
void createstack(stack &s)
{
    s.Top= NULL;
}


void push(stack &s, int x){
    NODE *p = createNODE(x);
    if(s.Top == NULL){
        s.Top=p;
    }
    else{
        p->pnext =s.Top;
        s.Top = p;
    }
}

void pop (stack &s, int value){
    if(s.Top == NULL){
        return; 
    }
    else {
        NODE *p =s.Top;
        s.Top =p ->pnext;
        value = p->data;
        delete p ;
    }
}

void nhap(stack &s, int n){

    for (int i =1;i<=n;i++){
        int x;
        cout << " Nhap vao cac gia tri: ";
        cin>> x;
        push(s, x);
    }
}

void printstack(stack s){
    cout << "STACK = Top<  ";
    for (NODE *k =s.Top; k!= NULL ; k=k->pnext){
        cout << k->data << "  ";
    }
    cout << ">" << endl;
}

 

bool checkrong(stack &s){
    if(s.Top = NULL){
        return true;}

    else{
        return false;
    }
}


void AvsB(stack &A, stack &B, stack &C){
        int n= A.Top->data;
        int value;
        if(A.Top != NULL && B.Top!=NULL){
            if(A.Top->data > B.Top->data){
                cout<<"Ko di chuyen dc"<<endl;
            }
            else if(A.Top->data < B.Top->data){
                push(B,n);
                pop(A,value);
            }
        }
        else{
            push(B,n);
            pop(A,value);
        }
        cout << "A: "<<endl; printstack(A);
        cout << "B: "<<endl; printstack(B);
        cout << "C: "<<endl; printstack(C);
        
}


void AvsC(stack &A, stack &B, stack &C){
        int n= A.Top->data;
        int value;
        if(A.Top != NULL && C.Top!=NULL){
            if(A.Top->data > C.Top->data){
                cout<<"Ko di chuyen dc"<<endl;
            }
            else if(A.Top->data < C.Top->data){
                push(C,n);
                pop(A,value);
            }
        }
        else{
            push(C,n);
            pop(A,value);
        }
        cout << "A: "<<endl; printstack(A);
        cout << "B: "<<endl; printstack(B);
        cout << "C: "<<endl; printstack(C);
}


void BvsA(stack &A, stack &B, stack &C){
        int n= B.Top->data;
        int value;
        if(B.Top != NULL && A.Top!=NULL){
            if(B.Top->data > A.Top->data){
                cout<<"Ko di chuyen dc"<<endl;
            }
            else if(B.Top->data < A.Top->data){
                push(A,n);
                pop(B,value);
            }
        }
        else{
            push(A,n);
            pop(B,value);
        }

        cout << "A: "<<endl; printstack(A);
        cout << "B: "<<endl; printstack(B);
        cout << "C: "<<endl; printstack(C);
}


void BvsC(stack &A, stack &B, stack &C){
    int n= B.Top->data;
    int value;
    if(B.Top != NULL && C.Top!=NULL){
        if(B.Top->data > C.Top->data){
            cout<<"Ko di chuyen dc"<<endl;
        }
        else if(B.Top->data < C.Top->data){
            push(C,n);
            pop(B,value);
        }
    }
    else{
        push(C,n);
        pop(B,value);
    }
    
    cout << "A: "<<endl; printstack(A);
    cout << "B: "<<endl; printstack(B);
    cout << "C: "<<endl; printstack(C);
}


void CvsB(stack &A, stack &B, stack &C){
    int n= C.Top->data;
        int value;
        if(C.Top != NULL && B.Top!=NULL){
            if(C.Top->data > B.Top->data){
                cout<<"Ko di chuyen dc"<<endl;
            }
            else if(C.Top->data < B.Top->data){
                push(B,n);
                pop(C,value);
            }
        }
        else{
            push(B,n);
            pop(C,value);  
        }
        
        cout << "A: "<<endl; printstack(A);
        cout << "B: "<<endl; printstack(B);
        cout << "C: "<<endl; printstack(C);
}

void CvsA(stack &A, stack &B, stack &C){
    int n= C.Top->data;
        int value;
        if(C.Top != NULL && A.Top!=NULL){
            if(C.Top->data > A.Top->data){
                cout<<"Ko di chuyen dc"<<endl;
            }
            else if(C.Top->data < A.Top->data){
                push(A,n);
                pop(C,value);
            }
        }
        else{
            push(A,n);
            pop(C,value); 
        }
        
        cout << "A: "<<endl; printstack(A);
        cout << "B: "<<endl; printstack(B);
        cout << "C: "<<endl; printstack(C);
}
// A   B   C 
//AB  AC  BA  BC  CA  CB

int main(){
    stack A;
    stack B;
    stack C;
    createstack(A);
    createstack(B);
    createstack(C);
    cout << "Nhap So Tang"<< endl;
    int tang;
    cin >> tang;
    for (int i =tang;i>=1;i--){
        push(A,i);
    }
    cout << "A: "; printstack(A);
    cout << "B: "; printstack(B);
    cout << "C: "; printstack(C);


while (true){
    cout << "1. A->B" << endl;
    cout << "2. A->C" << endl;
    cout << "3. B->A" << endl;
    cout << "4. B->C" << endl;
    cout << "5. C->A" << endl;
    cout << "6. C->B" << endl;


int chon;
cout << "Lua chon cua ban la: "<< endl;
cin >> chon ;
    switch (chon)
    {
    case 1:{
        if(A.Top == NULL){
            cout << "A dang trong." << endl;
            continue;
        }
        AvsB(A,B,C);
    break;      
    }

    case 2:{
        if(A.Top== NULL){
            cout<< "A dang trong." << endl;
            continue;
        }
        AvsC(A,B,C);
    break;   
    }

    case 3:{
        if(B.Top== NULL){
            cout<< "B dang trong." << endl;
            continue;
        }
        BvsA(A,B,C);
    break;   
    }

    case 4:{
        if(B.Top== NULL){
            cout<< "B dang trong." << endl;
            continue;
        }
        BvsC(A,B,C);
    break;
    }

    case 5:{
        if(C.Top== NULL){
            cout<< "C dang trong." << endl;
            continue;
        }
        CvsA(A,B,C);
    break; 
    }
    
    case 6:{
        if(C.Top== NULL){
            cout<< "C dang trong." << endl;
            continue;
        }
        CvsB(A,B,C);
    break;
    }
    default:
        break;
    }
}
}